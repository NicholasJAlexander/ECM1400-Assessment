""" This module contains functions that schedule and carry out Covid Data Updates """

import sys
import logging
from uk_covid19 import Cov19API
from shared_vars_funcs import (
    scheduler,
    config
    )

covid_API_data = {
    "local7days" : 0,
    "nat7days" : 0,
    "current_hospital_cases" : 0,
    "total_deaths" : 0
}

def last7days(
    data_list: list[dict or list],
    key_index: str or int,
    ignore: list
    ) -> int:
    """ Returns the sum of 7 specific data_list items key_index values

    Finds the first item in data_list whose key_index value in not in ignore list,
    and returns the sum of the 7 following data_list items key_index values.
    """
    cases = 0
    for day in range(len(data_list)-8):
        value = data_list[day][key_index]
        if value not in ignore:
            for item in data_list[day+1:day+8]:
                cases += int(item[key_index])
            break
    return cases

def parse_csv_data(csv_filename: str='nation_2021-10-28.csv') -> list[str]:
    """Returns a list of strings for the rows in the file"""
    if csv_filename[-4:] == '.csv':
        try:
            with open(csv_filename, encoding='ascii') as fin:
                logging.info('Csv data sucessfully parsed')
                output = [line.strip() for line in fin]
        except FileNotFoundError:
            logging.error('Csv data not parsed: FileNotFoundError')
            output = False
        except:
            logging.error('Csv data not parsed: \n\n%s\n', sys.exc_info())
            output = False
    else:
        logging.error('Csv data not parsed: File format not .csv')
        output = False

    return output

def process_covid_csv_data(covid_csv_data: list[str]) -> tuple[int,int,int]:
    """ Returns 3 integers:

    The number of cases in the last 7 days:
        Calculated using last7days function

    The current number of hospital cases:
        First integer entry in covid_csv_data for "hopsitalCases".

    The total number of deaths:
        First integer entry in covid_csv_data for "cumDailyNsoDeathsByDeathDate".
    """
    if covid_csv_data is False:
        logging.error('Error with input data')
        return 0 , 0 , 0
    # Splits, with delimiter=',', every string in covid_csv_data
    covid_csv_data = [line.split(',') for line in covid_csv_data]

    for line in covid_csv_data:
        value = line[5]
        if value not in ['hospitalCases', '']:
            current_hospital_cases = int(value)
            break

    last7days_cases = last7days(
        data_list =covid_csv_data,
        key_index = 6,
        ignore = ['newCasesBySpecimenDate', '']
        )

    for line in covid_csv_data:
        value = line[4]
        if value not in ['cumDailyNsoDeathsByDeathDate','']:
            total_deaths = int(value)
            break

    return last7days_cases , current_hospital_cases , total_deaths

def covid_API_request(
    location: str ='Exeter',
    location_type: str='ltla'
    ) -> dict[list[dict],list[dict]]:
    """Returns required local and national covid data

    Two covid API data requests are made:
        A local request for just new daily cases.
        A national request for daily hospital cases and new cases
        and total deaths.

    Both API requests return an object that is then turned into a dictionay,
    this dictionary has the following key-value pairs:
        'data': list of dictionarys(with keys specified by struc (see below))
        'last update': when the data that the API uses was last updated
        'lenght': size of 'data' list
        'total pages': number of pages requested, only 1 is being requested

    The function returns only the 'data' key value for the local and national
    API requests
    """
    # API filters
    filt = {
    'local': [
        f'areaName={location}',
        f'areaType={location_type}'
        ],
    'national': [
        'areaType=nation',
        f'areaName={config["data handler"]["nation"]}',
        ]
    }
    # Defines data requested and its structure.
    struc = {
    'local': {
        "areaName": "areaName",
        "areaType": "areaType",
        "date": "date",
        "newCasesBySpecimenDate": "newCasesBySpecimenDate",
        },
    'national': {
        "date": "date",
        "cumDailyNsoDeathsByDeathDate": "cumDailyNsoDeathsByDeathDate",
        "hospitalCases": "hospitalCases",
        "newCasesBySpecimenDate": "newCasesBySpecimenDate",
        },
    }

    # Uses filter and structure to initialise the Covid19API objects.
    api = Cov19API(filters=filt['local'], structure=struc['local'])
    nat_api = Cov19API(filters=filt['national'], structure=struc['national'])

    try:
        logging.info('Making Covid-19 API call')
        local_data = api.get_json()

        # Fetches data from API.
        nat_data = nat_api.get_json()
        logging.info('Successful Covid-19 API call')
    except:
        logging.error('Error with Covid-19 API call \n\n%s\n', sys.exc_info())
        local_data = {"data": False}
        nat_data = {"data": False}

    return {"local data": local_data['data'],
        "national data": nat_data['data']
        }

def process_API_data(
    local_national_data: dict[list[dict],list[dict]]
    ) -> tuple[int,int,int,int]:
    """Returns 4 integers:

    The number of local and national cases (as two seperate integers)
    in the last 7 days:
        Calculated by summing the newCasesBySpecimenDate for the last
        7 days, ignoring the first (integer) entry, from local_data, and
        nat_data respectively.

    The current number of hospital cases:
        First integer entry in nat_data for hopsitalCases.

    The total number of deaths:
        First integer entry in nat_data for cumDailyNsoDeathsByDeathDate.
    """
    local_data = local_national_data['local data']
    nat_data = local_national_data['national data']

    if local_data is not False:
        covid_API_data["local7days"] = last7days(
            data_list = local_data,
            key_index = 'newCasesBySpecimenDate',
            ignore = [None])
    else:
        logging.debug('Local Covid API data is False')

    if nat_data is not False:

        covid_API_data["nat7days"] = last7days(
            data_list = nat_data,
            key_index = 'newCasesBySpecimenDate',
            ignore = [None])

        # For each of the following "for" loops, the if statement finds the first
        # value that is not None.
        for day in nat_data:
            value = day['hospitalCases']
            if value is not None:
                covid_API_data["current_hospital_cases"] = int(value)

        for day in nat_data:
            value = day['cumDailyNsoDeathsByDeathDate']
            if value is not None:
                covid_API_data["total_deaths"] = int(value)
                break
    else:
        logging.debug('National Covid API data is False')

    # Return is for testing
    return covid_API_data

def update_covid_data(*update_name: str) -> list[str,str,str,str]:
    """Updates covid_API_data, if API has new data"""
    # This solves a problem I had with how the scheduler passed argument
    # to this function.
    update_name = ''.join(update_name)
    # If there is no internet the update will fail.
    process_API_data(
        covid_API_request(
            config["data handler"]["location"],
            config["data handler"]["location type"]
            )
        )
    schedule_covid_updates(update_name)
    # Return value used for testing testing
    return covid_API_data

def schedule_covid_updates(update_name: str , update_interval: int=86400) -> None:
    """ Schedules a covid data update in {update_interval} seconds"""
    scheduler.enter(update_interval,1,update_covid_data, update_name)
    logging.info('Coivd-19 update scheduled for update "%s"', update_name)
